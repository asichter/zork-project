// #ifndef ACTION_H_
// #define ACTION_H_

// #include <string>
// #include "Container.h"
// #include "Thing.h"

// class Action {
// protected:
//     std::string type;
//     std::string status;
//     std::string target;
//     Item * item;
//     Container * container;
    

// public:
//     Action();

//     virtual void display();

//     virtual void setItem(Item* _item);
//     virtual void setContainer(Container* _container);
//     virtual void setTarget(std::string _target);

//     virtual Item* getItem();
//     virtual Container* getContainer();
//     virtual std::string getTarget();
// };

// #endif
