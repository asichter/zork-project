// #include "../header/Action.h"
// #include <iostream>
// #include <string>

// Action::Action() {}

// void Action::display() { std::cout << "Action: " << getType() << std::endl; }

// void Action::setItem(Item* _item) { item = _item; }
// void Action::setContainer(Container * _container) { container = _container; }
// void Action::setTarget(std::string _target) { target = _target; }

// Item* Action::getItem() { return item; }
// Container* Action::getContainer() { return container; }
// std::string Action::getTarget() { return target; }
